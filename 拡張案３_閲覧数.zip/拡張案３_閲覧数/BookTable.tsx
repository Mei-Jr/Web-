"use client"; // クライアントサイドでの動き（filter）を有効にする

import { useState } from "react";

export default function BookTable({ initialBooks }: { initialBooks: any[] }) {
  const [selectedPublisher, setSelectedPublisher] = useState("");

  // 選択された出版社でフィルタリング
  const filteredBooks = selectedPublisher
    ? initialBooks.filter((book) => book.publisher === selectedPublisher)
    : initialBooks;

  // 出版社のリストを重複なく作成
  const publishers = Array.from(new Set(initialBooks.map((b) => b.publisher)));

  return (
    <>
      <select 
        value={selectedPublisher} 
        onChange={(e) => setSelectedPublisher(e.target.value)}
        style={{ marginBottom: "20px", padding: "5px" }}
      >
        <option value="">すべて</option>
        {publishers.map((pub) => (
          <option key={pub} value={pub}>{pub}</option>
        ))}
      </select>

      <table border={1} style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ backgroundColor: "#f2f2f2" }}>
            <th>id</th>
            <th>書籍名</th>
            <th>著者名</th>
            <th>出版社</th>
            <th>ジャンル</th>
            <th>価格</th>
            <th>在庫状況</th>
            <th>個数</th>
            <th>閲覧回数</th>
          </tr>
        </thead>
        <tbody>
          {filteredBooks.map((book) => (
            <tr key={book.id}>
              <td>{book.id}</td>
              <td>{book.title}</td>
              <td>{book.author || "-"}</td>
              <td>{book.publisher}</td>
              <td>{book.genre || "-"}</td>
              <td>{book.price || 0}</td>
              <td>{book.stock || 0}</td>
              <td>{book.quantity || 0}</td>
              <td>{book.views}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}