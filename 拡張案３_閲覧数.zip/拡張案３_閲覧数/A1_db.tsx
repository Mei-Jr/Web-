import mysql from 'mysql2/promise';

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'Meisei0523', // あなたのパスワード
  database: 'bookstore',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// ★ここが重要です！「default」をつけてエクスポートします
export default pool;