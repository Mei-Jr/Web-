from datetime import datetime, date, timedelta
from django.shortcuts import render
from .models import Receive, Area, Store


def all_receive_list(request):
    today = date.today()

    # 今日以降の受取のみ取得
    receives = Receive.objects.filter(receive_date__gte=today).order_by('receive_date')

    return render(request, 'myproject_books/all_receive_list.html', {
        'receives': receives
    })


def index(request):
    return render(
        request,
        'myproject_books/top.html'
    )


def area(request):
    areas = Area.objects.all().order_by('area_code')
    return render(request, 'myproject_books/area.html', {
        'areas': areas
    })


def store(request):
    area_code = request.GET.get("area_code")
    stores = Store.objects.all().order_by('store_code')
    if area_code:
        stores = stores.filter(area__area_code=area_code)
    return render(request, 'myproject_books/store.html', {
        'stores': stores
    })


def list_view(request):
    today = date.today()
    day_after_tomorrow = today + timedelta(days=2)
    store_code = request.GET.get("store_code")

    recent_data = Receive.objects.filter(
        receive_date__gte=today,
        receive_date__lte=day_after_tomorrow
    )

    if store_code:
        recent_data = recent_data.filter(store__store_code=store_code)  # ← ここ修正

    recent_data = recent_data.order_by('receive_date')

    return render(
        request,
        'myproject_books/list.html',
        {
            'recent_data': recent_data,
            'store_code': store_code,
        }
    )


def datelist(request):
    date_str = request.GET.get('date')

    if not date_str:
        data = []
        selected_date = None
    else:
        selected_date = datetime.strptime(date_str, "%Y-%m-%d").date()
        data = Receive.objects.filter(receive_date=selected_date)

    return render(
        request,
        'myproject_books/datelist.html',
        {
            'data': data,
            'date': selected_date,
        }
    )
