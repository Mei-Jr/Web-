from django.apps import AppConfig


class MyprojectBooksConfig(AppConfig):
    name = 'myproject_books'
