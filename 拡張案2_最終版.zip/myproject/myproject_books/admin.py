from django.contrib import admin
from .models import Receive, Store, Area

admin.site.register(Receive)
admin.site.register(Store)
admin.site.register(Area)

# Register your models here.
