from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='top'),
    path('all_receive/', views.all_receive_list, name='all_receive'),
    path('area/', views.area, name='area'),
    path('store/', views.store, name='store'),
    path('list/', views.list_view, name='list'),
    path('datelist/', views.datelist, name='datelist'),
]
